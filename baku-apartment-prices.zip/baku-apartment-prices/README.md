# Baku apartment price tracker

Scrapes apartment listings for Baku from bina.az and yeniemlak.az every 6 hours,
stores every price change in Postgres (Neon), and publishes a static analytics
dashboard to GitHub Pages.

```
GitHub Actions (cron, every 6 h)
  └─ scraper.run        bina.az (headless Chromium) + yeniemlak.az (HTTP)
       └─ Neon Postgres  listings · price_snapshots · scrape_runs
  └─ analytics.export   aggregates → dashboard/data.json
  └─ GitHub Pages       dashboard/index.html reads data.json
```

The dashboard never connects to the database, so no credentials reach the browser.

## What the dashboard shows

Filters: sale or rent, new or old building, number of rooms. For each combination:

- Median asking price per m², 4- and 12-week change, middle 50% range
- Weekly trend with a mix-adjusted line (district medians at fixed weights, so a week with more ads in cheap districts doesn't look like a price fall)
- District table: listings, median price, per m², 4-week change, new vs old build, gross rental yield
- District trend lines, rooms breakdown, price distribution, floor premium
- Share of ads that cut their price in the last 30 days and the typical cut
- Days listed before an ad disappears
- Feed of individual price changes with links to the ads
- Metro station table

## Setup (about 15 minutes)

1. **Database.** Create a Neon project and copy the connection string. Tables are created on first run.
2. **Repo.** Push this folder to a new GitHub repository.
3. **Secrets.** Settings → Secrets and variables → Actions → add `DATABASE_URL`. Add `PROXY_URL` only if you need it (see below).
4. **Pages.** Settings → Pages → Source: *GitHub Actions*.
5. **First run.** Actions → *Scrape and publish* → *Run workflow*. The dashboard URL appears on the run summary.

## Check the scrapers first

Run this locally before the first scheduled run, and again whenever a site changes its layout:

```bash
pip install -r requirements.txt
python -m playwright install chromium
python -m scraper.run --check
```

It reads one page per section, writes nothing, and prints how many cards parsed and the coverage of each field (price, area, rooms, floor, district, metro). If a section shows 0 usable cards, open the URL in `scraper/config.py` in a browser and update it. Parsing is text-based, so field extraction usually survives redesigns; only the section URL or the listing link pattern (`/items/<id>` on bina.az, `/elan/...-<id>` on yeniemlak.az) tends to break.

The yeniemlak.az rent URL (`elan_nov=2`) and page parameter (`&page=N`) are the two settings most worth confirming on the first check.

## If a site blocks the runner

yeniemlak.az is known to block cloud provider IP ranges, and GitHub's runners are cloud IPs. Two fixes:

- **Self-hosted runner** (free): any always-on machine (a home PC, a small office server in Baku). Settings → Actions → Runners → *New self-hosted runner*, then change `runs-on: ubuntu-latest` to `runs-on: self-hosted` in the `scrape` job.
- **Proxy**: set the `PROXY_URL` secret to a residential or local proxy.

Failed sections show as a red dot in the dashboard header, with the error on hover.

## Run locally

```bash
cp .env.example .env            # optional; without DATABASE_URL a local SQLite file is used
python -m scraper.run           # scrape
python -m analytics.export      # rebuild dashboard/data.json
python -m http.server -d dashboard 8000   # open http://localhost:8000
```

Preview with invented data:

```bash
DATABASE_URL=sqlite:///data/demo.db python -m tools.seed_demo
DATABASE_URL=sqlite:///data/demo.db python -m analytics.export
```

The `data.json` shipped in this repo is that demo output; the first real export replaces it.

## How the numbers work

- **Asking prices, not transactions.** Listing sites show what sellers ask.
- **Price history.** A snapshot is stored when an ad first appears and whenever its price changes, so history costs almost no storage.
- **Delisting.** When a run reaches the end of a section, ads not seen in it are marked delisted. A guard skips this if the run found under 60% of the active ads (a sign of blocking, not a market event). With the default `MAX_PAGES=40` the runs cover the newest ~1,000 ads per section; raise it to sweep whole sections.
- **Duplicates.** The same flat on both sites (same deal, rooms, rounded area, floor, building height and district or metro) is counted once.
- **Districts.** Taken from the ad; if only a metro station or settlement is named, the district is inferred from a small, editable map in `scraper/parse.py` and marked with * in the dashboard.
- **Currency.** USD prices are converted at the 1.70 peg.

## Be a good citizen

Keep `REQUEST_DELAY` at 3 seconds or more, check each site's terms of use and robots.txt, and don't republish the raw ads. Aggregated statistics are the intended output.

## Layout

```
scraper/      config.py (sections, settings) · parse.py · db.py · run.py · sources/bina.py · sources/yeniemlak.py
analytics/    export.py  → dashboard/data.json
dashboard/    index.html (static, Chart.js)
tools/        seed_demo.py
tests/        pytest
```
